<template>
  <q-page class="q-pa-md">
    <q-card>
      <!-- Header Section -->
      <q-card-section>
        <div class="row items-center justify-between">
          <div class="text-h6">Empresas</div>
          <q-btn flat round dense icon="close" @click="close" />
        </div>
        <div class="text-subtitle2 text-grey">Gerenciamento de empresas</div>
      </q-card-section>

      <q-separator />

      <!-- LIST VIEW -->
      <template v-if="viewMode === 'list'">
        <q-card-section>
          <div class="row items-center q-col-gutter-md q-mb-md">
            <div class="col-12 col-md-6">
              <q-input v-model="searchFilter" outlined dense placeholder="Buscar empresas..." clearable>
                <template v-slot:prepend>
                  <q-icon name="search" />
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-6 text-right">
              <q-btn class="q-pa-sm" unelevated color="primary" dense no-caps icon="add" label="Adicionar"
                @click="createNew" style="height: 40px;" />
            </div>
          </div>

          <q-table :rows="filteredCompanies" :columns="columns" row-key="id" :loading="loading" :pagination="pagination"
            @update:pagination="pagination = $event" flat bordered>
            <template v-slot:body-cell-actions="props">
              <q-td :props="props">
                <q-btn flat round dense color="primary" icon="edit" @click="editCompany(props.row)">
                  <q-tooltip>Editar</q-tooltip>
                </q-btn>
                <q-btn flat round dense color="negative" icon="delete" @click="confirmDelete(props.row)">
                  <q-tooltip>Excluir</q-tooltip>
                </q-btn>
              </q-td>
            </template>

            <template v-slot:no-data>
              <div class="full-width row flex-center text-grey q-gutter-sm q-pa-lg">
                <q-icon size="2em" name="sentiment_dissatisfied" />
                <span>Nenhuma empresa encontrada</span>
              </div>
            </template>

            <template v-slot:loading>
              <q-inner-loading showing color="primary" />
            </template>
          </q-table>
        </q-card-section>
      </template>

      <!-- FORM VIEW -->
      <template v-else>
        <!-- Back to List Button -->
        <q-card-section class="q-pb-none">
          <q-btn flat dense no-caps color="primary" icon="arrow_back" label="Voltar" @click="backToList" />
        </q-card-section>

        <!-- Company Data Section -->
        <q-card-section>
          <div class="text-subtitle1 q-mb-md text-weight-medium">Dados da Empresa</div>
          <div class="row q-col-gutter-md">
            <div class="col-12 col-md-6">
              <q-input v-model="companyStore.company.name" label="Nome da Empresa" outlined dense />
            </div>
            <div class="col-12 col-md-3">
              <q-select v-model="companyStore.company.companyGroupId" :options="groupOptions" label="Grupo Empresarial"
                outlined dense emit-value map-options />
            </div>
            <div class="col-12 col-md-3">
              <q-select v-model="companyStore.company.typeCompanyId" :options="typeOptions" label="Tipo de Empresa"
                outlined dense emit-value map-options />
            </div>
            <div class="col-12 col-md-6">
              <q-select v-model="companyStore.company.parentCompanyId" :options="parentCompanyOptions"
                label="Empresa Matriz" outlined dense emit-value map-options clearable />
            </div>
          </div>
        </q-card-section>

        <q-separator />

        <!-- Tabs Section -->
        <q-card-section class="q-pa-none flex flex-center">
          <q-tabs v-model="activeTab" no-caps dense class="text-primary full-width q-mt-md" active-color="primary"
            indicator-color="primary" align="center" narrow-indicator>
            <q-tab name="assinatura" label="Assinatura" icon="card_membership" />
            <q-tab name="endereco" label="Endereço" icon="location_on" />
            <q-tab name="contato" label="Contato" icon="contact_phone" />
            <q-tab name="powerbi" label="Power BI" icon="analytics" />
            <q-tab name="relatorios" label="Relatórios" icon="description" />
          </q-tabs>

          <q-separator />

          <q-tab-panels v-model="activeTab" animated class="q-pa-md">
            <!-- Tab Assinatura -->
            <q-tab-panel name="assinatura">
              <div class="text-subtitle1 q-mb-md text-weight-medium">Dados da Assinatura</div>
              <div class="row q-col-gutter-md">
                <div class="row full-width">
                  <q-input v-model="companySubscriptionStore.companySubscription.cnpj" label="CNPJ" outlined dense
                    mask="##.###.###/####-##" style="width: 160px;" class="q-mr-md" />
                  <q-select v-model="companySubscriptionStore.companySubscription.levelId" :options="levelOptions"
                    label="Nível" outlined dense emit-value map-options class="q-mr-md" style="width: 300px;" />
                  <q-input v-model.number="companySubscriptionStore.companySubscription.discount" label="Desconto (%)"
                    outlined dense type="number" min="0" max="100" suffix="%" class="q-mr-md" style="width: 120px;" />
                </div>
                <div class="row full-width">
                  <q-select v-model="companySubscriptionStore.companySubscription.methodPaymentId"
                    :options="methodPaymentOptions" label="Controle do Pagamento" outlined dense emit-value map-options
                    class="q-mr-md" style="width: 300px;" />
                  <q-select v-model="companySubscriptionStore.companySubscription.typeChargeId"
                    :options="periodChargeOptions" label="Período de Cobrança" outlined dense emit-value map-options
                    class="q-mr-md" style="width: 300px;" />
                </div>
              </div>
            </q-tab-panel>

            <!-- Tab Endereço -->
            <q-tab-panel name="endereco">
              <div class="text-subtitle1 q-mb-md text-weight-medium">Dados de Endereço</div>
              <div class="row q-col-gutter-md">
                <div class="col-12 col-md-3">
                  <q-input v-model="companyStore.address.cep" label="CEP" outlined dense mask="#####-###" />
                </div>
                <div class="col-12 col-md-7">
                  <q-input v-model="companyStore.address.street" label="Logradouro" outlined dense />
                </div>
                <div class="col-12 col-md-2">
                  <q-input v-model="companyStore.address.number" label="Número" outlined dense />
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.address.complement" label="Complemento" outlined dense />
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.address.neighborhood" label="Bairro" outlined dense />
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.address.city" label="Cidade" outlined dense />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.address.state" label="Estado" outlined dense />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.address.country" label="País" outlined dense />
                </div>
              </div>
              <div class="text-caption text-grey q-mt-md">
                * Implementação de busca automática por CEP será adicionada futuramente.
              </div>
            </q-tab-panel>

            <!-- Tab Contato -->
            <q-tab-panel name="contato">
              <div class="text-subtitle1 q-mb-md text-weight-medium">Dados de Contato</div>
              <div class="row q-col-gutter-md">
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.contact.name" label="Nome do Contato" outlined dense />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.contact.email" label="E-mail" outlined dense type="email" />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.contact.phone" label="Telefone" outlined dense mask="(##) ####-####" />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.contact.mobile" label="Celular" outlined dense
                    mask="(##) #####-####" />
                </div>
              </div>
              <div class="text-caption text-grey q-mt-md">
                * Implementação completa será adicionada futuramente.
              </div>
            </q-tab-panel>

            <!-- Tab Power BI -->
            <q-tab-panel name="powerbi">
              <div class="text-subtitle1 q-mb-md text-weight-medium">Credenciais Power BI</div>
              <div class="row q-col-gutter-md">
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.power_bi.clientId" label="Client ID" outlined dense />
                </div>
                <div class="col-12 col-md-6">
                  <q-input v-model="companyStore.power_bi.clientSecret" label="Client Secret" outlined dense
                    :type="showSecret ? 'text' : 'password'">
                    <template v-slot:append>
                      <q-icon :name="showSecret ? 'visibility' : 'visibility_off'" class="cursor-pointer"
                        @click="showSecret = !showSecret" />
                    </template>
                  </q-input>
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.power_bi.tenantId" label="Tenant ID" outlined dense />
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.power_bi.workspaceId" label="Workspace ID" outlined dense />
                </div>
                <div class="col-12 col-md-4">
                  <q-input v-model="companyStore.power_bi.reportId" label="Report ID" outlined dense />
                </div>
                <div class="col-12">
                  <q-input v-model="companyStore.power_bi.resourceUri" label="Resource URI" outlined dense />
                </div>
              </div>
              <div class="text-caption text-grey q-mt-md">
                * Implementação completa será adicionada futuramente.
              </div>
            </q-tab-panel>

            <!-- Tab Relatórios -->
            <q-tab-panel name="relatorios">
              <div class="text-subtitle1 q-mb-md text-weight-medium">Relatórios</div>
              <div class="text-center q-pa-xl">
                <q-icon name="description" size="64px" color="grey-5" />
                <div class="text-h6 text-grey-6 q-mt-md">Em desenvolvimento</div>
                <div class="text-body2 text-grey">
                  A gestão de relatórios será implementada futuramente.
                </div>
              </div>
            </q-tab-panel>
          </q-tab-panels>
        </q-card-section>

        <q-separator />

        <!-- Action Buttons -->
        <q-card-actions align="right" class="q-pa-md">
          <q-btn flat dense no-caps label="Cancelar" color="grey" @click="backToList"
            style="height: 35px; width: 100px;" />
          <q-btn unelevated dense no-caps label="Salvar" color="primary" @click="save" :loading="saving"
            style="height: 35px; width: 100px;" />
        </q-card-actions>
      </template>
    </q-card>

    <!-- Delete Confirmation Dialog -->
    <q-dialog v-model="showDeleteDialog" persistent>
      <q-card style="min-width: 350px">
        <q-card-section class="row items-center">
          <q-avatar icon="warning" color="negative" text-color="white" />
          <span class="q-ml-sm text-h6">Confirmar Exclusão</span>
        </q-card-section>

        <q-card-section>
          Tem certeza que deseja excluir a empresa <strong>{{ companyToDelete?.name }}</strong>?
          <br />
          <span class="text-caption text-grey">Esta ação não pode ser desfeita.</span>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="Cancelar" color="grey" v-close-popup />
          <q-btn flat label="Excluir" color="negative" @click="deleteCompany" :loading="deleting" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </q-page>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCompanyStore } from 'src/stores/module-company/company-store'
import { useCompanyGroupsStore } from 'src/stores/module-company/company.groups-store'
import { useCompanyTypeStore } from 'src/stores/module-company/company.type-store'
import { useTypeChargesStore } from 'src/stores/module-company/type.charges-store'
import { useCompanySubscriptionStore } from 'src/stores/module-company/company.subscription-store'
import { useLevelStore } from 'src/stores/module-level/level-store'
import { useMethodPaymentStore } from 'src/stores/module-method-payment/method.payment-store'

const router = useRouter()
const companyStore = useCompanyStore()
const groupStore = useCompanyGroupsStore()
const typeStore = useCompanyTypeStore()
const periodChargeStore = useTypeChargesStore()
const companySubscriptionStore = useCompanySubscriptionStore()
const levelStore = useLevelStore()
const methodPaymentStore = useMethodPaymentStore()

// View mode: 'list' or 'form'
const viewMode = ref('list')
const activeTab = ref('assinatura')
const showSecret = ref(false)

// Table state
const searchFilter = ref('')
const loading = ref(false)
const saving = ref(false)
const deleting = ref(false)
const isEditing = ref(false)

// Delete dialog
const showDeleteDialog = ref(false)
const companyToDelete = ref(null)

// Pagination
const pagination = ref({
  sortBy: 'name',
  descending: false,
  page: 1,
  rowsPerPage: 10
})

// Table columns
const columns = [
  {
    name: 'name',
    label: 'Nome',
    field: 'name',
    align: 'left',
    sortable: true
  },
  {
    name: 'company_group_name',
    label: 'Grupo',
    field: 'company_group_name',
    align: 'left',
    sortable: true
  },
  {
    name: 'type_company_name',
    label: 'Tipo',
    field: 'type_company_name',
    align: 'left',
    sortable: true
  },
  {
    name: 'parent_company_name',
    label: 'Empresa Matriz',
    field: 'parent_company_name',
    align: 'left',
    sortable: true
  },
  {
    name: 'actions',
    label: 'Ações',
    field: 'actions',
    align: 'center'
  }
]

// Computed: filtered companies for table
const filteredCompanies = computed(() => {
  if (!searchFilter.value) {
    return companyStore.companies || []
  }
  const search = searchFilter.value.toLowerCase()
  return (companyStore.companies || []).filter(company => {
    return (
      company.name?.toLowerCase().includes(search) ||
      company.company_group_name?.toLowerCase().includes(search) ||
      company.type_company_name?.toLowerCase().includes(search) ||
      company.parent_company_name?.toLowerCase().includes(search)
    )
  })
})

// Computed options for selects
const groupOptions = computed(() => {
  return groupStore.companyGroups?.map(group => ({
    label: group.name,
    value: group.id
  })) || []
})

const typeOptions = computed(() => {
  return typeStore.companyTypes?.map(type => ({
    label: type.name,
    value: type.id
  })) || []
})

const parentCompanyOptions = computed(() => {
  // Filter out current company from parent options
  const currentId = companyStore.company?.id
  return companyStore.companies
    ?.filter(c => c.id !== currentId)
    ?.map(company => ({
      label: company.name,
      value: company.id
    })) || []
})

const levelOptions = computed(() => {
  return levelStore.levels?.map(level => ({
    label: level.name,
    value: level.id
  })) || []
})

const methodPaymentOptions = computed(() => {
  return methodPaymentStore.methodPayments?.map(method => ({
    label: method.name,
    value: method.id
  })) || []
})

const periodChargeOptions = computed(() => {
  return periodChargeStore.typeCharges?.map(charge => ({
    label: charge.name,
    value: charge.id
  })) || []
})

// Load data
async function loadCompanies() {
  loading.value = true
  try {
    await companyStore.getAll()
  } finally {
    loading.value = false
  }
}

async function loadAuxiliarData() {
  await Promise.all([
    groupStore.getAll(),
    typeStore.getAll(),
    periodChargeStore.getAll(),
    companySubscriptionStore.getAll(),
    levelStore.getAll(),
    methodPaymentStore.getAll()
  ])
}

onMounted(() => {
  loadCompanies()
  loadAuxiliarData()
})

// Navigation
function close() {
  router.back()
}

async function backToList() {
  viewMode.value = 'list'
  companyStore.clear()
  activeTab.value = 'assinatura'
  isEditing.value = false

  await loadCompanies()
  await loadAuxiliarData()
}

// CRUD operations
function createNew() {
  companyStore.clear()
  isEditing.value = false
  viewMode.value = 'form'
}

async function editCompany(company) {
  loading.value = true
  try {
    await companyStore.getById(company.id)
    isEditing.value = true
    viewMode.value = 'form'
  } finally {
    loading.value = false
  }
}

function confirmDelete(company) {
  companyToDelete.value = company
  showDeleteDialog.value = true
}

async function deleteCompany() {
  if (!companyToDelete.value) return

  deleting.value = true
  try {
    await companyStore.delete(companyToDelete.value.id)
    await loadCompanies()
    showDeleteDialog.value = false
    companyToDelete.value = null
  } finally {
    deleting.value = false
  }
}

async function save() {
  saving.value = true
  try {
    if (isEditing.value) {
      await companyStore.update(companyStore.company.id)
      await companySubscriptionStore.update(companySubscriptionStore.companySubscription.id)
    } else {
      await companyStore.create()
      await companySubscriptionStore.create()
    }
    await loadCompanies()
    backToList()
  } finally {
    saving.value = false
  }
}
</script>
