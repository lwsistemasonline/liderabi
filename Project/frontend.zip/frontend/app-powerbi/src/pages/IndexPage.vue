<template>
  <q-page class="flex flex-center page-background">
    <img alt="Quasar logo" src="~assets/Logo_2025_LideraTI.png" style="width: 400px; height: 400px" />
  </q-page>
</template>

<script setup>
//
</script>

<style scoped>
.page-background {
  background-color: transparent;
}
</style>
