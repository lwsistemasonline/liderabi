import { defineStore } from 'pinia'
import { api } from 'src/boot/axios'
import { Notify } from 'quasar'
import { useAuthStore } from 'src/stores/module-auth/auth-store'

export const useCompanySubscriptionStore = defineStore('companySubscriptionStore', {
    state: () => ({
        companySubscriptions: [],
        companySubscription: {
            id: undefined,
            companyId: undefined,
            levelId: undefined,
            discount: undefined,
            methodPaymentId: undefined,
            typeChargeId: undefined,
            cnpj: undefined,
            createdAt: undefined,
            updatedAt: undefined,
            deletedAt: undefined,
        }
    }),

    getters: {
    },

    actions: {

        clear() {
            this.companySubscription = {
                id: '',
                companyId: '',
                levelId: '',
                discount: '',
                methodPaymentId: '',
                typeChargeId: '',
                cnpj: '',
                createdAt: new Date(),
                updatedAt: new Date(),
                deletedAt: '',
            }
        },

        async getAll() {
            const authStore = useAuthStore()
            const token = authStore.token

            try {
                const response = await api.get('/company-subscriptions', { headers: { 'Authorization': `Bearer ${token}` } })

                if (response.status === 200) {
                    this.companySubscriptions = response.data
                    return true
                } else {
                    Notify.create({
                        message: 'Erro ao buscar assinaturas de empresas',
                        color: 'red',
                        icon: 'close',
                        timeout: 3000,
                        position: 'center',
                    })
                    return false
                }
            } catch (error) {
                Notify.create({
                    message: error.message || 'Erro ao buscar assinaturas de empresas',
                    color: 'red',
                    icon: 'close',
                    timeout: 3000,
                    position: 'center',
                })
                return false
            }
        },

        async getById(id) {
            const authStore = useAuthStore()
            const token = authStore.token

            try {
                const response = await api.get(`/company-subscriptions/${id}`, { headers: { 'Authorization': `Bearer ${token}` } })

                if (response.status === 200) {
                    this.companySubscription = response.data
                    return true
                } else {
                    Notify.create({
                        message: response.data.message || 'Erro ao buscar assinatura de empresa',
                        color: 'red',
                        icon: 'close',
                        timeout: 3000,
                        position: 'center',
                    })
                    return false
                }
            } catch (error) {
                Notify.create({
                    message: error.message || 'Erro ao buscar assinatura de empresa',
                    color: 'red',
                    icon: 'close',
                    timeout: 3000,
                    position: 'center',
                })
                return false
            }
        },

        async create() {
            const authStore = useAuthStore()
            const token = authStore.token

            try {
                const response = await api.post('/company-subscriptions', this.companySubscription, { headers: { 'Authorization': `Bearer ${token}` } })

                if (response.status === 201) {
                    this.companySubscription = response.data
                    return true
                } else {
                    Notify.create({
                        message: response.data.message || 'Erro ao criar assinatura de empresa',
                        color: 'red',
                        icon: 'close',
                        timeout: 3000,
                        position: 'center',
                    })
                    return false
                }
            } catch (error) {
                Notify.create({
                    message: error.message || 'Erro ao criar assinatura de empresa',
                    color: 'red',
                    icon: 'close',
                    timeout: 3000,
                    position: 'center',
                })
                return false
            }
        },

        async update(id) {
            const authStore = useAuthStore()
            const token = authStore.token

            try {
                const response = await api.put(`/company-subscriptions/${id}`, this.companySubscription, { headers: { 'Authorization': `Bearer ${token}` } })

                if (response.status === 200) {
                    this.companySubscription = response.data
                    return true
                } else {
                    Notify.create({
                        message: response.data.message || 'Erro ao atualizar assinatura de empresa',
                        color: 'red',
                        icon: 'close',
                        timeout: 3000,
                        position: 'center',
                    })
                    return false
                }
            } catch (error) {
                Notify.create({
                    message: error.message || 'Erro ao atualizar assinatura de empresa',
                    color: 'red',
                    icon: 'close',
                    timeout: 3000,
                    position: 'center',
                })
                return false
            }
        },

        async delete(id) {
            const authStore = useAuthStore()
            const token = authStore.token

            try {
                const response = await api.delete(`/company-subscriptions/${id}`, { headers: { 'Authorization': `Bearer ${token}` } })

                if (response.status === 200) {
                    this.companySubscription = response.data
                    return true
                } else {
                    Notify.create({
                        message: response.data.message || 'Erro ao deletar assinatura de empresa',
                        color: 'red',
                        icon: 'close',
                        timeout: 3000,
                        position: 'center',
                    })
                    return false
                }
            } catch (error) {
                Notify.create({
                    message: error.message || 'Erro ao deletar assinatura de empresa',
                    color: 'red',
                    icon: 'close',
                    timeout: 3000,
                    position: 'center',
                })
                return false
            }
        }
    },

})